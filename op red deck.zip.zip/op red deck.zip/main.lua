-- BEansofbeansjokers mod
print("[BEansofbeansjokers] ===== MOD LOADED =====")

local M = {}
local blueprint_count = 100

function M.init()
    print("[BEansofbeansjokers] init() called")
end

function M.post_init()
    print("[BEansofbeansjokers] post_init() called")
    if G and G.localization and G.localization.descriptions then
        if G.localization.descriptions.Back then
            G.localization.descriptions.Back.b_red = {
                name = "Red Deck",
                text = {
                    "GIVES 100 BLUEPRINT JOKERS AND 1",
                    "ANCIENT JOKER",
                    "{C:attention}Warning!{} this will cause lag",
                    "unless you have a nasa pc and if you",
                    "have a low end pc it might {C:red}crash/not",
                    "respond{}"
                }
            }
            print("[BEansofbeansjokers] Red Deck description set!")
        end
    end
end

function M.set_blueprint_count(count)
    blueprint_count = count
end

function M.get_blueprint_count()
    return blueprint_count
end

print("[BEansofbeansjokers] ===== MOD INITIALIZATION COMPLETE =====")

return M
