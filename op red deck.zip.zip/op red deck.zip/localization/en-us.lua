return {
    descriptions = {
        Back = {
            b_red = {
                name = "Red Deck",
                text = {
                    "GIVES 100 BLUEPRINT JOKERS AND 1",
                    "ANCIENT JOKER",
                    "{C:attention}Warning!{} this will cause lag",
                    "unless you have a nasa pc and if you",
                    "have a low end pc it might crash/not",
                    "respond"
                }
            }
        }
    }
}
